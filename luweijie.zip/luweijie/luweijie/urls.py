from django.contrib import admin
from django.urls import path
from catalog import views  # 导入你刚才写的 views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),  # 访问根目录（主页）时，执行 views.index
    path('about/',views.about,name='about'),
    path('add_book/', views.add_book,name='add_book'),
    path('book_list/', views.book_list, name='book_list'),  # 展示页
    path('delete-book/<int:book_id>/', views.delete_book, name='delete_book'),

]
