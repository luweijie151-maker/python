from django.shortcuts import render
from django.shortcuts import render, redirect
from .models import Book, Author, Bookid, Category

def index(request):
    return render(request, 'catalog/index.html')
    
def about(request):
    name = "卢伟杰"
    role = "Python 全栈开发学习者"
    return render(request, 'catalog/about.html', {'name': name, 'role': role})

def init_categories():
    categories = ['Романы', 'Наука и техника', ' История', 'Литература']
    for name in categories:
        Category.objects.get_or_create(name=name)

def add_book(request):
    init_categories()
    error = ''
    
    if request.method == 'POST':
        title = request.POST['title']
        author_name = request.POST['author']
        bookid = request.POST['bookid']
        
        if Bookid.objects.filter(info=bookid).exists():
            error = "Данные книги уже есть, дублирование недопустимо!"
        else:
            author, _ = Author.objects.get_or_create(name=author_name)
            bookid = Bookid.objects.create(info=bookid)

            book = Book.objects.create(
                title=title,
                author=author,
                bookid=bookid
            )

            # 勾选的分类直接绑定
            cate_ids = request.POST.getlist('categories')
            book.categories.set(cate_ids)

            return redirect('add_book')

    categories = Category.objects.all()
    return render(request, 'catalog/add_book.html', {
        'categories': categories,
        'error': error
    })

def book_list(request):
    books = Book.objects.all()
    return render(request, 'catalog/book_list.html', {'books': books})
    
def delete_book(request, book_id):
    try:
        # 找到这本书
        book = Book.objects.get(id=book_id)
       
        for rel in book._meta.related_objects:
            if rel.one_to_one:
                related_name = rel.remote_field.name
                if hasattr(book, related_name):
                    getattr(book, related_name).delete()

        book.delete()

    except:
        pass

    return redirect('book_list')



