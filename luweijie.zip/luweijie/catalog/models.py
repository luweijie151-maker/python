from django.db import models

# 作者
class Author(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

# 书籍详情（一对一）
class Bookid(models.Model):
    info = models.CharField(max_length=100)

    def __str__(self):
        return self.info

# 分类
class Category(models.Model):
    name = models.CharField(max_length=30)

    def __str__(self):
        return self.name

# 书籍
class Book(models.Model):
    title = models.CharField(max_length=100)

    # 一对多
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    # 一对一
    bookid = models.OneToOneField(Bookid, on_delete=models.CASCADE)
    # 多对多
    categories = models.ManyToManyField(Category)

